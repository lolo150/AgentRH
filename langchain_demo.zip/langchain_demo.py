from pathlib import Path
from datetime import datetime

# Décorateur pour transformer une fonction Python en "tool" utilisable par l'agent
from langchain.tools import tool

# Fonction LangChain qui crée un agent simple prêt à l'emploi
from langchain.agents import create_agent

# Connecteur OpenAI-compatible : ici il pointe vers LM Studio en local
from langchain_openai import ChatOpenAI


# --------------------------------------------------
# 1) Dossier sécurisé pour écrire les fichiers
# --------------------------------------------------
BASE_DIR = Path("sandbox")
BASE_DIR.mkdir(exist_ok=True)


# --------------------------------------------------
# 2) Outil : récupérer l'heure actuelle
# --------------------------------------------------
@tool
def get_current_time() -> str:
    """Retourne la date et l'heure actuelles."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# --------------------------------------------------
# 3) Outil : créer un fichier texte
# --------------------------------------------------
@tool
def create_note(filename: str, content: str) -> str:
    """Crée un fichier texte dans le dossier sandbox avec le contenu donné."""
    path = BASE_DIR / filename
    path.write_text(content, encoding="utf-8")
    return f"Fichier créé : {path.resolve()}"


# --------------------------------------------------
# 4) Connexion au LLM local via LM Studio
# --------------------------------------------------
llm = ChatOpenAI(
    model="Meta-Llama-3-8B-Instruct-Q4_K_M.gguf",
    temperature=0,
    openai_api_base="http://127.0.0.1:1234/v1",
    openai_api_key="lm-studio"
)


# --------------------------------------------------
# 5) Création de l'agent
# --------------------------------------------------
agent = create_agent(
    model=llm,
    tools=[get_current_time, create_note],
    system_prompt=(
        "Tu es un assistant local. "
        "Quand une demande nécessite une action concrète, utilise les outils disponibles."
    ),
)


# --------------------------------------------------
# 6) Prompt utilisateur
# --------------------------------------------------
user_prompt = (
    "Donne-moi l'heure actuelle puis crée un fichier memo.txt "
    "contenant une phrase naturelle avec cette heure."
)


# --------------------------------------------------
# 7) Exécution
# --------------------------------------------------
result = agent.invoke({
    "messages": [
        {"role": "user", "content": user_prompt}
    ]
})

print(result)